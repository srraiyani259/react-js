import React from 'react'

function Image(props) {

    return (
    <div>



    </div>
  )
}

export default Image