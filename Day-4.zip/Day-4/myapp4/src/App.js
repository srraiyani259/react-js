import logo from './logo.svg';
import './App.css';
import Counter from './Counter.js';
import Img from './bg.jpg';

function App() {
  return (
    <div className="App">
      <Counter Back={Img}/>
    </div>
  );
}

export default App;