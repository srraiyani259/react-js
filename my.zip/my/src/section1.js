import React from 'react'

function Sec() {
  return (
  
    <div className='bg'><br/><br/><br/>
      <div className="main">
        <div className="text">
              <h1> Sign In Here </h1>
        </div>
        <div className="username">
          <input type="text" name="username" value="" placeholder="Enter Username"/><br/><br/>
          <input type="text2" name="password" value="" placeholder="Enter Password"/><br/><br/><br/>
        </div> 

        <div className="submit">
            <input type="submit" name="Sign-In" value="Sign-In"/>
        </div>

              <div className="box"><br/>
                  
                  <h5>Remember me&&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Need help?</h5><br/><br/><br/><br/><br/><br/>
              </div>
                  
              <div className="text1">
                  <p>Need to Netflix? <b>Sign up now.</b></p><br/>
              </div>

              <div className="text2">
                  <p>This page is protected by Google reCAPTCHA to</p>
                  <p>ensure you're not a bot. <a href="">Learn more.</a></p>
              </div>
      </div>
    </div>
  )
}

export default Sec