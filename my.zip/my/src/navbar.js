import React from 'react'

function Navbar() {
  return (
    <div className='nav'>
      <img src=''/>
      <center>
        <a href=''>Home</a>
        <a href=''>About</a>
        <a href=''>Contact</a>
        <a href=''>Help</a>
        <a href=''>Submit</a>
        </center>
    </div>
  )
}

export default Navbar