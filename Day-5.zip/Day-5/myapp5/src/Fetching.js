import React from 'react'
import { useState , useEffect } from 'react'

function Fetching() {
  
   
        const[data , setData] = useState(null)

        const FetchingData = async()=>{
            let response = await fetch('https://fakestoreapi.com/products/1')
            let jsonData = await response.json()

            console.log(jsonData)
            setData(jsonData)
        }
        FetchingData()
    
  
    return (
    <div>
        {
            data && data.map((el)=>(
                <h1>{el.title}</h1>
            ))
        }
    </div>
  )
}

export default Fetching