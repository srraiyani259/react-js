import logo from './logo.svg';
import './App.css';
import './Fetching.js';
import Fetching from './Fetching.js';

function App() {
  return (
    <div className="App">
      <Fetching/>
    </div>
  );
}

export default App;
